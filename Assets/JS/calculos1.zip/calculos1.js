function calc-index (params) {console.log('sumapares'+);console.log('sumaimpares';)
calc-index=sumapares/sumaimpares
alert('indice calculado es:' calc-index)
}
function sumapares (n) {n=5
    if (n<=0) return;
console.log ('sumapares#'+n);n=5 sumapares(n-1);}

function sumaimpares (n) {n=5
    if (n<=0) return;
    console.log ('sumaimpares#'+n);n=5 sumaimpares(n-1);}

    